<?php
include('connection.php');

// Constants
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutes

// Utility Functions
class AuthUtils {
    public static function sanitizeInput($input) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function generateUserId($prefix, $conn) {
        $base_id = $prefix . "_" . date("mdY_His");
        $user_id = $base_id;
        $counter = 1;
        
        do {
            $stmt = $conn->prepare("SELECT user_id FROM users_table WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) break;
            $user_id = $base_id . "_" . (++$counter);
        } while (true);
        
        return $user_id;
    }

    public static function checkRateLimit($ip) {
        $attempts = isset($_SESSION['login_attempts'][$ip]) ? $_SESSION['login_attempts'][$ip] : 0;
        $lastAttempt = isset($_SESSION['last_attempt'][$ip]) ? $_SESSION['last_attempt'][$ip] : 0;
        
        if ($attempts >= MAX_LOGIN_ATTEMPTS && (time() - $lastAttempt) < LOCKOUT_TIME) {
            $remainingTime = LOCKOUT_TIME - (time() - $lastAttempt);
            return ['locked' => true, 'remaining' => ceil($remainingTime / 60)];
        }
        return ['locked' => false];
    }
}

// Initialize session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check database connection
if ($conn->connect_error) {
    http_response_code(500);
    exit(json_encode(['error' => 'Database connection failed']));
}

// Main request handler
$action = isset($_REQUEST['action']) ? AuthUtils::sanitizeInput($_REQUEST['action']) : '';

switch ($action) {
    case 'check_admin':
        if ($_SERVER["REQUEST_METHOD"] !== "GET") break;
        
        $stmt = $conn->prepare("SELECT email FROM users_table WHERE user_type = 'administrator'");
        $stmt->execute();
        $result = $stmt->get_result();
        
        $response = ['adminExists' => false, 'adminEmails' => ''];
        
        if ($result->num_rows > 0) {
            $emails = array_map(fn($row) => $row['email'], $result->fetch_all(MYSQLI_ASSOC));
            $response = [
                'adminExists' => true,
                'adminEmails' => implode(',', $emails)
            ];
        }
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();

    case 'register':
        if ($_SERVER["REQUEST_METHOD"] !== "POST") break;
        
        // Rate limit check
        $rateLimitCheck = AuthUtils::checkRateLimit($_SERVER['REMOTE_ADDR']);
        if ($rateLimitCheck['locked']) {
            header("Location: /pages/auth/register_as_admin.php?message=Too many attempts. Please try again in {$rateLimitCheck['remaining']} minutes.&status=danger");
            exit();
        }
        
        // Validate required fields
        $required_fields = ['username', 'firstname', 'lastname', 'email', 'password', 'confirm_password', 'contact_num'];
        $input_data = array_map([AuthUtils::class, 'sanitizeInput'], array_intersect_key($_POST, array_flip($required_fields)));
        
        if (count(array_filter($input_data)) !== count($required_fields)) {
            header("Location: /pages/auth/register_as_admin.php?message=All required fields must be filled&status=danger");
            exit();
        }
        
        // Extract and validate data
        extract($input_data);
        $middlename = AuthUtils::sanitizeInput($_POST['middlename'] ?? '');
        
        if (!AuthUtils::validateEmail($email)) {
            header("Location: /pages/auth/register_as_admin.php?message=Invalid email format&status=danger");
            exit();
        }
        
        if ($password !== $confirm_password) {
            header("Location: /pages/auth/register_as_admin.php?message=Passwords do not match&status=danger");
            exit();
        }
        
        // Process registration
        $conn->begin_transaction();
        
        try {
            $user_id = AuthUtils::generateUserId("user", $conn);
            $password_hash = password_hash($password, PASSWORD_ARGON2ID);
            $created_at = gmdate('Y-m-d H:i:s');
            
            $stmt = $conn->prepare("INSERT INTO users_table (user_id, username, firstname, middlename, lastname, email, contact_num, password_hash, user_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'administrator', ?)");
            $stmt->bind_param("sssssssss", 
                $user_id, $username, $firstname, $middlename, $lastname, 
                $email, $contact_num, $password_hash, $created_at
            );
            $stmt->execute();
            
            $conn->commit();
            
            unset($_SESSION['login_attempts'][$_SERVER['REMOTE_ADDR']]);
            header("Location: /pages/auth/login.php?message=Registration successful&status=success");
            exit();
            
        } catch (Exception $e) {
            $conn->rollback();
            header("Location: /pages/auth/register_as_admin.php?message=" . urlencode($e->getMessage()) . "&status=danger");
            exit();
        }
        break;

    default:
        header("Location: /pages/auth/login.php?message=Invalid action&status=danger");
        exit();
}
?>
