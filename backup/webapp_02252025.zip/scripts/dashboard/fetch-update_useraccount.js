document.addEventListener('DOMContentLoaded', function() {
    // Function to fetch account data
    function fetchAccountData() {
        fetch('/php/dashboard/fetch-update_useraccount.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=fetch'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('userUsername').value = data.data.username;
                document.getElementById('userEmail').value = data.data.email;
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: data.message,
                });
            }
        })
        .catch(error => {
            console.error('Error fetching account data:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to fetch account data. Please check the console.',
            });
            console.log("Raw JSON data:", error);
        });
    }

    // Fetch account data on page load
    fetchAccountData();

    // Handle form submission for updating account
    document.getElementById('account-form').addEventListener('submit', function(event) {
        event.preventDefault();

        const userUsername = document.getElementById('userUsername').value;
        const userEmail = document.getElementById('userEmail').value;

        fetch('/php/dashboard/fetch-update_useraccount.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=update&username=${userUsername}&email=${userEmail}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: data.message,
                    showConfirmButton: false,
                    timer: 1500
                }).then(() => {
                    fetchAccountData(); // Refresh account data
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: data.message,
                });
            }
        })
        .catch(error => {
            console.error('Error updating account:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to update account. Please check the console.',
            });
        });
    });
});
