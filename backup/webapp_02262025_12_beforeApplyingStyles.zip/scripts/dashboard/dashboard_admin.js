document.addEventListener('DOMContentLoaded', function() {
    loadUsers('administrator', 'adminTableBody');
    loadUsers('healthcare_provider', 'healthcareProviderTableBody');
    loadUsers('receptionist', 'receptionistTableBody');
    loadUsers('patient', 'patientTableBody');

    // Handle both forms
    ['website-settings-form', 'website-customization-form'].forEach(formId => {
        const form = document.getElementById(formId);
        if (form) {
            form.addEventListener('submit', async function(event) {
                event.preventDefault();

                console.log(`Form ID: ${formId} submitted`);

                const formData = new FormData(this);

                // Determine which form is being submitted
                const isCustomizationForm = formId === 'website-customization-form';

                // Selectors for the fields
                const orgNameSelector = isCustomizationForm ? 'org-name' : 'org-name';
                const homepageTitleSelector = isCustomizationForm ? 'homepage-title' : 'homepage-title';
                const heroTextTitleSelector = isCustomizationForm ? 'hero-text-title' : 'hero-text-title';
                const heroTextSubtitleSelector = isCustomizationForm ? 'hero-text-subtitle' : 'hero-text-subtitle';
                const contactEmailSelector = isCustomizationForm ? 'contact-email' : 'contact-email';
                const contactNumSelector = isCustomizationForm ? 'contact-num' : 'contact-num';
                const addressSelector = isCustomizationForm ? 'address' : 'address';
                const adActiveUsersSelector = isCustomizationForm ? 'ad-active-users' : 'ad-active-users';
                const adHealthcarePartnersSelector = isCustomizationForm ? 'ad-healthcare-partners' : 'ad-healthcare-partners';
                const adUptimeSelector = isCustomizationForm ? 'ad-uptime' : 'ad-uptime';
                const adSupportSelector = isCustomizationForm ? 'ad-support' : 'ad-support';
                const sloganFooterSelector = isCustomizationForm ? 'slogan-footer' : 'slogan-footer';
                const colorDashboardSelector = isCustomizationForm ? 'color-dashboard' : 'color-dashboard';
                const legalPagesRevisionDateSelector = isCustomizationForm ? 'legal-pages-revision-date' : 'legal-pages-revision-date';

                // Create a config object to hold the non-file data
                const config = {
                    'org-name': document.getElementById(orgNameSelector)?.value || '',
                    'homepage-title': document.getElementById(homepageTitleSelector)?.value || '',
                    'hero-text-title': document.getElementById(heroTextTitleSelector)?.value || '',
                    'hero-text-subtitle': document.getElementById(heroTextSubtitleSelector)?.value || '',
                    'contact-email': document.getElementById(contactEmailSelector)?.value || '',
                    'contact-num': document.getElementById(contactNumSelector)?.value || '',
                    'address': document.getElementById(addressSelector)?.value || '',
                    'ad-active-users': document.getElementById(adActiveUsersSelector)?.value || '',
                    'ad-healthcare-partners': document.getElementById(adHealthcarePartnersSelector)?.value || '',
                    'ad-uptime': document.getElementById(adUptimeSelector)?.value || '',
                    'ad-support': document.getElementById(adSupportSelector)?.value || '',
                    'slogan-footer': document.getElementById(sloganFooterSelector)?.value || '',
                    'color-dashboard': document.getElementById(colorDashboardSelector)?.value || '',
                    'legal-pages-revision-date': document.getElementById(legalPagesRevisionDateSelector)?.value || ''
                };

                console.log('Config being sent:', config);
                formData.append('config', JSON.stringify(config));

                fetch('/php/website_config/fetch-update_websiteconfig.php', {
                    method: 'POST',
                    body: formData,
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(data => {
                    try {
                        const jsonData = JSON.parse(data);
                        if (jsonData.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: jsonData.success,
                                showConfirmButton: false,
                                timer: 1850,
                                allowOutsideClick: false
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: jsonData.error,
                            });
                        }
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                        console.log('Raw response data:', data);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Failed to update configuration. Please check the console.',
                        });
                    }
                })
                .catch(error => {
                    console.error('Error updating configuration:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Failed to update configuration. Please check the console.',
                    });
                });
            });
        } else {
            console.warn(`Form with ID ${formId} not found.`);
        }
    });
});

function loadUsers(userType, tableId) {
    fetch('/php/dashboard/dashboard_admin.php?action=get' + userType.charAt(0).toUpperCase() + userType.slice(1) + 's')
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            populateTable(data.users, tableId, userType);
        } else {
            console.error('Error fetching ' + userType + 's:', data.message);
        }
    });
}

function populateTable(users, tableId, userType) {
    const tableBody = document.getElementById(tableId);
    tableBody.innerHTML = ''; // Clear existing data

    users.forEach(user => {
        let row = tableBody.insertRow();
        row.insertCell(0).textContent = user.user_id;
        row.insertCell(1).textContent = user.fullname || user.username;
        row.insertCell(2).textContent = user.email;

        let actionsCell = row.insertCell(3);
        actionsCell.innerHTML = `
            <button class="btn btn-sm btn-info" onclick="editUser('${user.user_id}', '${userType}')">Edit</button>
            <button class="btn btn-sm btn-danger" onclick="removeUser('${user.user_id}', '${userType}')">Remove</button>
            <a class="btn btn-sm btn-info" href="mailto:${user.email}" target="_blank">Message</a>
        `;
    });
}

function removeUser(userId, userType) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('/php/dashboard/dashboard_admin.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=removeUser&user_id=${userId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({ // Added properties
                        icon: 'success',
                        title: 'Deleted!',
                        text: 'User has been deleted.',
                        showConfirmButton: false,
                        timer: 1850,
                        allowOutsideClick: false
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire(
                        'Error!',
                        'There was an error deleting the user.',
                        'error'
                    );
                }
            });
        }
    });
}

function addUser(userType) {
    Swal.fire({
        title: 'Add New ' + userType.charAt(0).toUpperCase() + userType.slice(1),
        html: `
            <input id="swal-input-username" class="swal2-input" placeholder="Username">
            <input id="swal-input-firstname" class="swal2-input" placeholder="First Name">
            <input id="swal-input-middlename" class="swal2-input" placeholder="Middle Name">
            <input id="swal-input-lastname" class="swal2-input" placeholder="Last Name">
            <input id="swal-input-password" class="swal2-input" placeholder="Password" type="password">
            <input id="swal-input-email" class="swal2-input" placeholder="Email" type="email">
            <input id="swal-input-contact" class="swal2-input" placeholder="Contact Number">
            <input id="swal-input-address" class="swal2-input" placeholder="Address">
        `,
        confirmButtonText: 'Add',
        focusConfirm: false,
        preConfirm: () => {
            return {
                username: document.getElementById('swal-input-username').value,
                firstname: document.getElementById('swal-input-firstname').value,
                middlename: document.getElementById('swal-input-middlename').value,
                lastname: document.getElementById('swal-input-lastname').value,
                password: document.getElementById('swal-input-password').value,
                email: document.getElementById('swal-input-email').value,
                contact_num: document.getElementById('swal-input-contact').value,
                address: document.getElementById('swal-input-address').value
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const userData = result.value;
            fetch('/php/dashboard/dashboard_admin.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=add${userType.charAt(0).toUpperCase() + userType.slice(1)}&username=${userData.username}&firstname=${userData.firstname}&middlename=${userData.middlename}&lastname=${userData.lastname}&password=${userData.password}&email=${userData.email}&contact_num=${userData.contact_num}&address=${userData.address}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({ // Added properties
                        icon: 'success',
                        title: 'Added!',
                        text: 'New ' + userType + ' has been added.',
                        showConfirmButton: false,
                        timer: 1850,
                        allowOutsideClick: false
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire(
                        'Error!',
                        'There was an error adding the ' + userType + '.',
                        'error'
                    );
                }
            });
        }
    })
}

function addAdmin() {
    addUser('administrator');
}

function addHealthcareProvider() {
    addUser('healthcare_provider');
}

function addReceptionist() {
    addUser('receptionist');
}

function addPatient() {
    addUser('patient');
}

function editUser(userId, userType) {
    fetch('/php/dashboard/dashboard_admin.php?action=getUser&user_id=' + userId)
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            const user = data.user;
            Swal.fire({
                title: 'Edit ' + userType.charAt(0).toUpperCase() + userType.slice(1),
                html: `
                    <input id="swal-input-username" class="swal2-input" placeholder="Username" value="${user.username}">
                    <input id="swal-input-firstname" class="swal2-input" placeholder="First Name" value="${user.firstname}">
                    <input id="swal-input-middlename" class="swal2-input" placeholder="Middle Name" value="${user.middlename}">
                    <input id="swal-input-lastname" class="swal2-input" placeholder="Last Name" value="${user.lastname}">
                    <input id="swal-input-email" class="swal2-input" placeholder="Email" type="email" value="${user.email}">
                    <input id="swal-input-contact" class="swal2-input" placeholder="Contact Number" value="${user.contact_num}">
                    <input id="swal-input-address" class="swal2-input" placeholder="Address" value="${user.address}">
                `,
                confirmButtonText: 'Update',
                focusConfirm: false,
                preConfirm: () => {
                    return {
                        username: document.getElementById('swal-input-username').value,
                        firstname: document.getElementById('swal-input-firstname').value,
                        middlename: document.getElementById('swal-input-middlename').value,
                        lastname: document.getElementById('swal-input-lastname').value,
                        email: document.getElementById('swal-input-email').value,
                        contact_num: document.getElementById('swal-input-contact').value,
                        address: document.getElementById('swal-input-address').value
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const userData = result.value;
                    // TODO: Implement update functionality here
                    console.log('Update user:', userId, userData);
                    Swal.fire(
                        'Updated!',
                        'User information has been updated.',
                        'success'
                    ).then(() => {
                        loadUsers(userType, userType + 'TableBody');
                    });
                }
            });
        } else {
            Swal.fire(
                'Error!',
                'There was an error fetching user data.',
                'error'
            );
        }
    });
}
