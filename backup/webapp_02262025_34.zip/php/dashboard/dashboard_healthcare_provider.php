<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/php/connection.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    // Copy relevant cases from receptionist dashboard
    // ...copy those cases...
    
    case 'getAppointments':
        getAppointments();
        break;
    case 'completeAppointment':
        completeAppointment();
        break;
    default:
        echo json_encode(['status' => 'error', 'message' => 'Invalid action.']);
}

// Copy relevant functions from receptionist dashboard
// ...copy those functions...

function getAppointments() {
    global $conn;
    $status = $_GET['status'] ?? 'upcoming';
    $providerId = $_GET['provider'] ?? '';
    $searchTerm = $_GET['search'] ?? '';
    
    $query = "SELECT 
                a.*,
                CONCAT(p.firstname, ' ', p.lastname) as patient_name
              FROM appointments_table a
              JOIN users_table p ON a.patient = p.user_id
              WHERE a.healthcare_provider = ? 
              AND a.status = ?
              AND (
                  p.firstname LIKE ? OR 
                  p.lastname LIKE ? OR
                  a.type LIKE ?
              )
              ORDER BY a.time_start ASC";
    
    $searchPattern = "%$searchTerm%";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", 
        $providerId,
        $status,
        $searchPattern, 
        $searchPattern, 
        $searchPattern
    );
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $row['time_start'] = (new DateTime($row['time_start']))->format('Y-m-d H:i:s');
        $row['time_end'] = (new DateTime($row['time_end']))->format('Y-m-d H:i:s');
        $appointments[] = $row;
    }
    
    $stmt->close();
    echo json_encode(['status' => 'success', 'appointments' => $appointments]);
}

function completeAppointment() {
    global $conn;
    $id = $_POST['id'];
    
    $query = "UPDATE appointments_table SET status = 'completed' WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update appointment']);
    }
    $stmt->close();
}
