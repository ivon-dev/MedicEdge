function loadUsers(userType, tableId) {
    // ...copy from dashboard_receptionist.js...
}

function populateTable(users, tableId, userType) {
    // ...copy from dashboard_receptionist.js...
}

function searchMedicalRecords() {
    // ...copy from dashboard_receptionist.js...
}

function loadMedicalRecords(searchTerm = '') {
    // ...copy from dashboard_receptionist.js...
}

function populateMedicalRecordsTable(patients) {
    // ...copy from dashboard_receptionist.js...
}

function editMedicalRecord(userId) {
    // ...copy from dashboard_receptionist.js...
}

function showMedicalRecordEditor(userId, medicalRecord) {
    // ...copy from dashboard_receptionist.js...
}

function updateMedicalRecord(userId, medicalRecord) {
    // ...copy from dashboard_receptionist.js...
}

// Healthcare Provider specific functions
function loadAppointments(status = 'upcoming', searchTerm = '') {
    const sessionToken = document.cookie.replace(/(?:(?:^|.*;\s*)session_token\s*\=\s*([^;]*).*$)|^.*$/, "$1");
    let userId = null;
    if (sessionToken) {
        try {
            const decodedToken = JSON.parse(atob(sessionToken.split('.')[1]));
            userId = decodedToken.user_id;
        } catch (e) {
            console.error("Error decoding session token:", e);
            return;
        }
    }

    fetch(`/php/dashboard/dashboard_healthcare_provider.php?action=getAppointments&status=${status}&provider=${userId}&search=${searchTerm}`)
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            populateAppointmentsTable(data.appointments);
        } else {
            console.error('Error fetching appointments:', data.message);
        }
    });
}

function populateAppointmentsTable(appointments) {
    const tableBody = document.getElementById('appointmentsTableBody');
    tableBody.innerHTML = '';

    appointments.forEach(appointment => {
        let row = tableBody.insertRow();
        
        const startTime = new Date(appointment.time_start).toLocaleString([], { 
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        const endTime = new Date(appointment.time_end).toLocaleString([], {
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        row.insertCell(0).textContent = `${startTime} - ${endTime}`;
        row.insertCell(1).textContent = appointment.patient_name;
        row.insertCell(2).textContent = appointment.type;

        let statusCell = row.insertCell(3);
        let statusClass = '';
        switch(appointment.status) {
            case 'upcoming':
                statusClass = 'bg-primary';
                break;
            case 'completed':
                statusClass = 'bg-success';
                break;
            case 'cancelled':
                statusClass = 'bg-danger';
                break;
        }
        statusCell.innerHTML = `<span class="badge ${statusClass}">${appointment.status}</span>`;

        let actionsCell = row.insertCell(4);
        let actions = `
            <button class="btn btn-sm btn-info" onclick="editAppointment('${appointment.id}')">View/Edit</button>
        `;
        
        if (appointment.status === 'upcoming') {
            actions += `
                <button class="btn btn-sm btn-success" onclick="markAsCompleted('${appointment.id}')">Mark as Completed</button>
            `;
        }
        
        actionsCell.innerHTML = actions;
    });
}

function editAppointment(appointmentId) {
    // ...copy from dashboard_receptionist.js...
}

function markAsCompleted(appointmentId) {
    Swal.fire({
        title: 'Complete Appointment',
        text: "Are you sure you want to mark this appointment as completed?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, complete it'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('/php/dashboard/dashboard_healthcare_provider.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=completeAppointment&id=${appointmentId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire('Success', 'Appointment marked as completed', 'success');
                    loadAppointments('upcoming');
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            });
        }
    });
}

function searchAppointments() {
    const searchTerm = document.getElementById('appointmentsSearch').value.toLowerCase();
    const activeTab = document.querySelector('.nav-tabs .active').textContent.toLowerCase();
    loadAppointments(activeTab, searchTerm);
}

document.addEventListener('DOMContentLoaded', function() {
    loadUsers('patient', 'patientTableBody');
    loadMedicalRecords();
    loadAppointments('upcoming');
});
