document.addEventListener('DOMContentLoaded', function() {
    document.cookie = "request_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; SameSite=Lax;";
});
