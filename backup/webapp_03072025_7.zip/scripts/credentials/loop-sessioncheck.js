function checkSession() {
    fetch('/php/api/userinfo.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data === "empty") {
            document.body.innerHTML = '';
            Swal.fire({
                title: 'Access Denied',
                text: 'UserID should not be blank. Please login again.',
                icon: 'error',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: true,
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = '/pages/auth/login.php';
            });
        }
    })
    .catch(error => {
        console.error('Session check failed:', error);
    });
}

// Initial check
checkSession();

// Set up the interval for checking every 8 seconds
setInterval(checkSession, 8000);
